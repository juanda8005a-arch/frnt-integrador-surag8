# Cursos React 

## Instalar y ejecutar

npm install
npm run dev


## Qué hace
- Permite agregar cursos (nombre, plataforma, progreso)
- Lista y búsqueda.
- El progreso actualiza el estado: Pendiente / En progreso / Completado
- Guarda todo en `localStorage` (persistencia en el navegador)
- agregar la decha 
- tambien la modalidad presencial/virtual
- Falta mas cosas :) 
