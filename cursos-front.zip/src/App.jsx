import React, { useEffect, useMemo, useState } from "react";
import { Link, Navigate, Route, Routes, useNavigate, useParams } from "react-router-dom";

const STORAGE_KEY = "cursos";
const AUTH_KEY = "cursos_auth";

function uid() {
  return `${Date.now()}_${Math.random().toString(16).slice(2)}`;
}
function safeParse(json, fallback) {
  try { return JSON.parse(json) ?? fallback; } catch { return fallback; }
}
function labelStatus(s){
  if (s === "DONE") return "Completado";
  if (s === "IN_PROGRESS") return "En progreso";
  return "Pendiente";
}

function Notice({ notice, onClose }){
  if (!notice) return null;
  return (
    <div
      role="alert"
      style={{
        padding: "8px 10px",
        borderRadius: 8,
        background: notice.type === "success" ? "#E7F7EE" : "#FDECEC",
        color: notice.type === "success" ? "#1B7F43" : "#B42318",
        border: `1px solid ${notice.type === "success" ? "#B7E4C7" : "#F5C2C7"}`,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 10,
      }}
    >
      <span>{notice.message}</span>
      <button
        type="button"
        aria-label="Cerrar"
        onClick={onClose}
        style={{
          border: "none",
          background: "transparent",
          cursor: "pointer",
          fontSize: 16,
          lineHeight: 1,
          color: "inherit",
        }}
      >
        x
      </button>
    </div>
  );
}

function Topbar(){
  return (
    <nav className="topbar-wrap">
      <div className="topbar">
        <Link className="topbar-item" to="/">Inicio</Link>
        <Link className="topbar-item" to="/login">Inicio de sesión</Link>
        <Link className="topbar-item" to="/cursos">Cursos</Link>
      </div>
    </nav>
  );
}

function RequireAuth({ auth, children }){
  if (!auth) return <Navigate to="/login" replace />;
  return children;
}

function HomePage(){
  return (
    <div className="container">
      <div className="card">
        <h2>Bienvenido</h2>
        <div className="muted">Usa la barra para navegar entre Inicio de sesión y Cursos.</div>
      </div>
    </div>
  );
}

function LoginPage({ auth, setAuth }){
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  function handleLogin(e){
    e?.preventDefault?.();
    const email = loginEmail.trim().toLowerCase();
    const password = loginPassword.trim();
    if (!email || !password) {
      setLoginError("Completa email y contraseña.");
      return;
    }
    setLoginError("");
    setAuth({ email, loggedInAt: Date.now() });
    setLoginPassword("");
  }

  if (auth) return <Navigate to="/cursos" replace />;

  return (
    <div className="container">
      <div className="row" style={{justifyContent:"space-between", marginBottom: 10}}>
        <div>
          <h1>Iniciar sesión</h1>
          <div className="muted">Accede para gestionar tus cursos.</div>
        </div>
      </div>

      <div className="card" style={{maxWidth: 420}}>
        <form onSubmit={handleLogin} style={{display:"grid", gap: 10}}>
          <label>
            Email
            <input
              value={loginEmail}
              onChange={(e)=>setLoginEmail(e.target.value)}
              placeholder="tucorreo@ejemplo.com"
              type="email"
              autoComplete="email"
            />
          </label>

          <label>
            Contraseña
            <input
              value={loginPassword}
              onChange={(e)=>setLoginPassword(e.target.value)}
              placeholder="********"
              type="password"
              autoComplete="current-password"
            />
          </label>

          {loginError ? <div className="muted">{loginError}</div> : null}

          <button className="primary" type="submit">Entrar</button>
        </form>
      </div>
    </div>
  );
}

function CursosPage({ auth, onLogout, courses, setCourses, storageNotice, clearStorageNotice }){
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  function removeCourse(id){
    const ok = confirm("¿Eliminar este curso?");
    if (!ok) return;
    setCourses(prev => prev.filter(c => c.id !== id));
  }

  function updateProgress(id, value){
    const p = Math.max(0, Math.min(100, Number(value) || 0));
    const status = p === 0 ? "PENDING" : p === 100 ? "DONE" : "IN_PROGRESS";
    setCourses(prev => prev.map(c =>
      c.id === id ? { ...c, progress: p, status, updatedAt: Date.now() } : c
    ));
  }

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return courses;
    return courses.filter(c => {
      return (c.name || "").toLowerCase().includes(q) ||
             (c.platform || "").toLowerCase().includes(q);
    });
  }, [courses, query]);

  return (
    <div className="container">
      <div className="row" style={{justifyContent:"space-between", marginBottom: 10}}>
        <div>
          <h1>Cursos</h1>
        </div>
        <div className="row" style={{gap: 10}}>
          <div className="muted">{auth?.email}</div>
          <button className="small" onClick={onLogout}>Salir</button>
        </div>
      </div>

      <div className="row" style={{marginBottom: 10, justifyContent:"space-between"}}>
        <button className="primary" onClick={() => navigate("/cursos/registrar")}>Registrar curso</button>
        <input
          style={{flex:1, minWidth: 220}}
          value={query}
          onChange={(e)=>setQuery(e.target.value)}
          placeholder="Buscar por nombre o plataforma..."
        />
      </div>

      {storageNotice ? (
        <div style={{marginBottom: 10}}>
          <Notice notice={storageNotice} onClose={clearStorageNotice} />
        </div>
      ) : null}

      <div style={{display:"grid", gap: 10}}>
        {filtered.length === 0 ? (
          <div className="muted">No hay cursos.</div>
        ) : filtered.map(c => (
          <div className="item" key={c.id}>
            <div className="item-title">
              <div style={{minWidth:0}}>
                <div style={{display:"flex", gap: 8, alignItems:"center", flexWrap:"wrap"}}>
                  <span>{c.name}</span>
                  <span className="badge">{labelStatus(c.status)}</span>
                </div>
              </div>

              <div className="actions">
                <button className="small" onClick={()=>navigate(`/cursos/editar/${c.id}`)}>Editar</button>
                <button className="small" onClick={()=>removeCourse(c.id)}>Eliminar</button>
              </div>
            </div>

            <div className="progress">
              <div style={{width: `${Math.max(0, Math.min(100, Number(c.progress) || 0))}%`}} />
            </div>

            <div className="row" style={{marginTop: 8}}>
              <label style={{margin:0}}>
                Cambiar progreso
                <input
                  className="small"
                  style={{width: 120}}
                  type="number"
                  min="0"
                  max="100"
                  defaultValue={c.progress ?? 0}
                  onBlur={(e)=>updateProgress(c.id, e.target.value)}
                />
              </label>
              <div className="muted" style={{marginLeft:"auto"}}>
                Actualizado: {new Date(c.updatedAt || c.createdAt).toLocaleString()}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CourseFormPage({ mode, courses, setCourses, storageNotice, clearStorageNotice }){
  const navigate = useNavigate();
  const params = useParams();
  const editingCourse = mode === "edit" ? courses.find(c => c.id === params.id) : null;

  const [name, setName] = useState("");
  const [platform, setPlatform] = useState("");
  const [progress, setProgress] = useState(0);
  const [modality, setModality] = useState("VIRTUAL");
  const [chapters, setChapters] = useState(1);
  const [rating, setRating] = useState(0);
  const [courseDate, setCourseDate] = useState(() => {
    const d = new Date();
    return d.toISOString().slice(0, 10);
  });
  const [teacher, setTeacher] = useState("Juan");
  const [formNotice, setFormNotice] = useState(null);

  useEffect(() => {
    if (!editingCourse) return;
    setName(editingCourse.name || "");
    setPlatform(editingCourse.platform || "");
    setProgress(editingCourse.progress ?? 0);
    setModality(editingCourse.modality || "VIRTUAL");
    setChapters(editingCourse.chapters ?? 1);
    setRating(editingCourse.rating ?? 0);
    setCourseDate(editingCourse.courseDate || new Date().toISOString().slice(0, 10));
    setTeacher(editingCourse.teacher || "Juan");
  }, [editingCourse]);

  function clearNotices(){
    if (formNotice) setFormNotice(null);
  }

  function handleSubmit(e){
    e?.preventDefault?.();
    const cleanName = name.trim();
    if (!cleanName) {
      setFormNotice({ type: "error", message: "Falta el nombre del curso. No se guardó." });
      return;
    }

    const cleanPlatform = platform.trim();
    const p = Math.max(0, Math.min(100, Number(progress) || 0));
    const ch = Math.max(0, Number(chapters) || 0);
    const r = Math.max(0, Math.min(5, Number(rating) || 0));
    const createdDate = courseDate || new Date().toISOString().slice(0, 10);
    const status = p === 0 ? "PENDING" : p === 100 ? "DONE" : "IN_PROGRESS";
    const now = Date.now();

    if (mode === "edit"){
      if (!editingCourse) {
        setFormNotice({ type: "error", message: "Curso no encontrado." });
        return;
      }
      setCourses(prev => prev.map(c =>
        c.id === editingCourse.id ? {
          ...c,
          name: cleanName,
          platform: cleanPlatform,
          progress: p,
          modality,
          chapters: ch,
          rating: r,
          courseDate: createdDate,
          teacher,
          status,
          updatedAt: now,
        } : c
      ));
      setFormNotice({ type: "success", message: "Curso actualizado con éxito." });
      return;
    }

    setCourses(prev => [{
      id: uid(),
      name: cleanName,
      platform: cleanPlatform,
      progress: p,
      modality,
      chapters: ch,
      rating: r,
      courseDate: createdDate,
      teacher,
      status,
      createdAt: now,
      updatedAt: now,
    }, ...prev]);

    setFormNotice({ type: "success", message: "Curso registrado con éxito." });
    setName("");
    setPlatform("");
    setProgress(0);
    setModality("VIRTUAL");
    setChapters(1);
    setRating(0);
    setCourseDate(new Date().toISOString().slice(0, 10));
    setTeacher("Juan");
  }

  if (mode === "edit" && !editingCourse) {
    return (
      <div className="container">
        <div className="card">
          <div className="muted">No se encontró el curso.</div>
          <button className="small" style={{marginTop: 10}} onClick={() => navigate("/cursos")}>Volver</button>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="row" style={{justifyContent:"space-between", marginBottom: 10}}>
        <h1>{mode === "edit" ? "Editar curso" : "Registrar curso"}</h1>
        <button className="small" onClick={() => navigate("/cursos")}>Volver</button>
      </div>

      <div className="card">
        <form onSubmit={handleSubmit} style={{display:"grid", gap: 10}}>
          <label>
            Nombre *
            <input value={name} onChange={(e)=>{ setName(e.target.value); clearNotices(); }} placeholder="Ej: React básico" />
          </label>

          <label>
            Plataforma
            <input value={platform} onChange={(e)=>{ setPlatform(e.target.value); clearNotices(); }} placeholder="Ej: Udemy" />
          </label>

          <label>
            Modalidad
            <select value={modality} onChange={(e)=>{ setModality(e.target.value); clearNotices(); }}>
              <option value="PRESENCIAL">Presencial</option>
              <option value="VIRTUAL">Virtual</option>
            </select>
          </label>

          <label>
            Capítulos del curso
            <input type="number" min="0" value={chapters} onChange={(e)=>{ setChapters(e.target.value); clearNotices(); }} />
          </label>

          <label>
            Calificación (0 a 5)
            <input type="number" min="0" max="5" step="0.5" value={rating} onChange={(e)=>{ setRating(e.target.value); clearNotices(); }} />
          </label>

          <label>
            Fecha de creación del curso
            <input type="date" value={courseDate} onChange={(e)=>{ setCourseDate(e.target.value); clearNotices(); }} />
          </label>

          <label>
            Progreso (%)
            <input type="number" min="0" max="100" value={progress} onChange={(e)=>{ setProgress(e.target.value); clearNotices(); }} />
          </label>

          <label>
            Maestro/a
            <select value={teacher} onChange={(e)=>{ setTeacher(e.target.value); clearNotices(); }}>
              <option value="Juan">Juan</option>
              <option value="Luis">Luis</option>
              <option value="Ana">Ana</option>
            </select>
          </label>

          <button className="primary" type="submit">Guardar</button>

          {formNotice ? (
            <Notice notice={formNotice} onClose={() => setFormNotice(null)} />
          ) : null}

          {storageNotice ? (
            <Notice notice={storageNotice} onClose={clearStorageNotice} />
          ) : null}
        </form>
      </div>
    </div>
  );
}

export default function App() {
  const [auth, setAuth] = useState(() => {
    const saved = localStorage.getItem(AUTH_KEY);
    return safeParse(saved, null);
  });
  const [courses, setCourses] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    const initial = safeParse(saved, []);
    return Array.isArray(initial) ? initial : [];
  });
  const [storageNotice, setStorageNotice] = useState(null);

  useEffect(() => {
    if (auth) localStorage.setItem(AUTH_KEY, JSON.stringify(auth));
    else localStorage.removeItem(AUTH_KEY);
  }, [auth]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(courses));
    } catch (error) {
      setStorageNotice({ type: "error", message: "No se pudieron guardar los datos." });
      console.error("Error guardando cursos:", error);
    }
  }, [courses]);

  function handleLogout(){
    setAuth(null);
  }

  return (
    <>
      <Topbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage auth={auth} setAuth={setAuth} />} />
        <Route
          path="/cursos"
          element={(
            <RequireAuth auth={auth}>
              <CursosPage
                auth={auth}
                onLogout={handleLogout}
                courses={courses}
                setCourses={setCourses}
                storageNotice={storageNotice}
                clearStorageNotice={() => setStorageNotice(null)}
              />
            </RequireAuth>
          )}
        />
        <Route
          path="/cursos/registrar"
          element={(
            <RequireAuth auth={auth}>
              <CourseFormPage
                mode="create"
                courses={courses}
                setCourses={setCourses}
                storageNotice={storageNotice}
                clearStorageNotice={() => setStorageNotice(null)}
              />
            </RequireAuth>
          )}
        />
        <Route
          path="/cursos/editar/:id"
          element={(
            <RequireAuth auth={auth}>
              <CourseFormPage
                mode="edit"
                courses={courses}
                setCourses={setCourses}
                storageNotice={storageNotice}
                clearStorageNotice={() => setStorageNotice(null)}
              />
            </RequireAuth>
          )}
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}
